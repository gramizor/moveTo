// src/App.tsx
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import { setToken } from './store/tokenSlice';

const Home = () => <div>Home Page</div>;
const MoveTo = () => <div>Move To Page</div>;
const Auth = () => <div>Authentication Page</div>;

const App = () => {
  const dispatch = useDispatch();
  const token = useSelector((state: any) => state.token.token);

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      dispatch(setToken(storedToken));
    }
  }, [dispatch]);

  return (
      <Router>
        <Switch>
          <Route path="/" exact>
            {token ? <Home /> : <Redirect to="/auth" />}
          </Route>
          <Route path="/move_to" exact>
            {token ? <MoveTo /> : <Redirect to="/auth" />}
          </Route>
          <Route path="/auth" exact>
            {!token ? <Auth /> : <Redirect to="/" />}
          </Route>
        </Switch>
      </Router>
  );
};

export default App;
